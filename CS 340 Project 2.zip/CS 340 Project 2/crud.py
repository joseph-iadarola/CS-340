from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections. 
        self.client = MongoClient('mongodb://%s:%s@localhost:27017/AAC' % (username, password))
        # where xxxxx is your unique port number
        self.database = self.client.AAC

# Complete this create method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
            try:
                response = self.database.animals.insert_one(data)  # data should be dictionary
            except Exception:
                return False
            return response.acknowledged and bool(response.inserted_id)             
        else:
            raise Exception("Nothing to save, because data parameter is empty")

# Create method to implement the R in CRUD.
    def read(self, data):
        if data is not None:
            animal_data = self.database.animals.find(data)  # data should be dictionary
            fixed_data = []
            add_data = fixed_data.append
            for item in animal_data:
                item['_id'] = str(item['_id'])
                add_data(item)
            return fixed_data
        else:
            raise Exception("Nothing to find, because data parameter is empty")

# Create method to implement the U in CRUD.
    def update(self,lookup,data):
        if data is None:
            raise Exception("Nothing to update")
        response = self.database.animals.update_many(lookup, {"$set": data})
        if response.acknowledged:
            return response.raw_result

# Create method to implement the D in CRUD.
    def delete(self,data):
        if data is None:
            raise Exception("Nothing to delete")
        response = self.database.animals.delete_many(data)
        if response.acknowledged:
            return response.raw_result